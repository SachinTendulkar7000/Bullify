import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertStockSchema,
  insertStockPriceSchema,
  insertEconomicIndicatorSchema,
  insertEconomicDataSchema,
  insertSectorPerformanceSchema,
  insertSectorPredictionSchema,
  insertWatchlistSchema, 
  insertWatchlistItemSchema
} from "@shared/schema";

// Cubin Scale types
export interface CubinScaleData {
  score: number;
  confidence: number;
  factors: {
    gdpImpact: number;
    newsImpact: number;
    marketImpact: number;
    aiPrediction: number;
  };
  summary: string;
  recommendations: string[];
  timestamp: string;
}

export function registerRoutes(app: Express): Server {
  setupAuth(app);
  const httpServer = createServer(app);

  // User Routes
  app.get("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const users = await storage.getUsers();
    res.json(users);
  });

  // Stock Routes
  app.get("/api/stocks", async (req, res) => {
    try {
      const sector = req.query.sector?.toString();
      let stocks;

      if (sector) {
        stocks = await storage.getStocksBySector(sector);
      } else {
        stocks = await storage.getStocks();
      }

      res.json(stocks);
    } catch (error) {
      console.error("Error fetching stocks:", error);
      res.status(500).json({ error: "Failed to fetch stocks" });
    }
  });

  app.get("/api/stocks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const stock = await storage.getStock(id);

      if (!stock) {
        return res.status(404).json({ error: "Stock not found" });
      }

      res.json(stock);
    } catch (error) {
      console.error("Error fetching stock:", error);
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  app.get("/api/stocks/symbol/:symbol", async (req, res) => {
    try {
      const symbol = req.params.symbol.toUpperCase();
      const stock = await storage.getStockBySymbol(symbol);

      if (!stock) {
        return res.status(404).json({ error: "Stock not found" });
      }

      res.json(stock);
    } catch (error) {
      console.error("Error fetching stock by symbol:", error);
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  app.post("/api/stocks", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const stockData = insertStockSchema.parse(req.body);
      const stock = await storage.createStock(stockData);
      res.status(201).json(stock);
    } catch (error) {
      console.error("Error creating stock:", error);
      res.status(400).json({ error: "Invalid stock data" });
    }
  });

  // Stock Prices Routes
  app.get("/api/stocks/:stockId/prices", async (req, res) => {
    try {
      const stockId = parseInt(req.params.stockId);
      const startDate = req.query.startDate ? new Date(req.query.startDate.toString()) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate.toString()) : undefined;

      const prices = await storage.getStockPrices(stockId, startDate, endDate);
      res.json(prices);
    } catch (error) {
      console.error("Error fetching stock prices:", error);
      res.status(500).json({ error: "Failed to fetch stock prices" });
    }
  });

  app.post("/api/stockprices", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const priceData = insertStockPriceSchema.parse(req.body);
      const price = await storage.createStockPrice(priceData);
      res.status(201).json(price);
    } catch (error) {
      console.error("Error creating stock price:", error);
      res.status(400).json({ error: "Invalid stock price data" });
    }
  });

  // Economic Indicators Routes
  app.get("/api/indicators", async (req, res) => {
    try {
      const category = req.query.category?.toString();
      let indicators;

      if (category) {
        indicators = await storage.getEconomicIndicatorsByCategory(category);
      } else {
        indicators = await storage.getEconomicIndicators();
      }

      res.json(indicators);
    } catch (error) {
      console.error("Error fetching economic indicators:", error);
      res.status(500).json({ error: "Failed to fetch economic indicators" });
    }
  });

  app.get("/api/indicators/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const indicator = await storage.getEconomicIndicator(id);

      if (!indicator) {
        return res.status(404).json({ error: "Economic indicator not found" });
      }

      res.json(indicator);
    } catch (error) {
      console.error("Error fetching economic indicator:", error);
      res.status(500).json({ error: "Failed to fetch economic indicator" });
    }
  });

  app.post("/api/indicators", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const indicatorData = insertEconomicIndicatorSchema.parse(req.body);
      const indicator = await storage.createEconomicIndicator(indicatorData);
      res.status(201).json(indicator);
    } catch (error) {
      console.error("Error creating economic indicator:", error);
      res.status(400).json({ error: "Invalid economic indicator data" });
    }
  });

  // Economic Data Routes
  app.get("/api/indicators/:indicatorId/data", async (req, res) => {
    try {
      const indicatorId = parseInt(req.params.indicatorId);
      const startDate = req.query.startDate ? new Date(req.query.startDate.toString()) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate.toString()) : undefined;

      const data = await storage.getEconomicData(indicatorId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching economic data:", error);
      res.status(500).json({ error: "Failed to fetch economic data" });
    }
  });

  app.post("/api/economicdata", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const economicData = insertEconomicDataSchema.parse(req.body);
      const data = await storage.createEconomicData(economicData);
      res.status(201).json(data);
    } catch (error) {
      console.error("Error creating economic data:", error);
      res.status(400).json({ error: "Invalid economic data" });
    }
  });

  // Sector Performance Routes
  app.get("/api/sectors/performance", async (req, res) => {
    try {
      const date = req.query.date ? new Date(req.query.date.toString()) : undefined;
      const performances = await storage.getAllSectorPerformance(date);
      res.json(performances);
    } catch (error) {
      console.error("Error fetching sector performances:", error);
      res.status(500).json({ error: "Failed to fetch sector performances" });
    }
  });

  app.get("/api/sectors/:sector/performance", async (req, res) => {
    try {
      const sector = req.params.sector;
      const startDate = req.query.startDate ? new Date(req.query.startDate.toString()) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate.toString()) : undefined;

      const performances = await storage.getSectorPerformance(sector, startDate, endDate);
      res.json(performances);
    } catch (error) {
      console.error("Error fetching sector performance:", error);
      res.status(500).json({ error: "Failed to fetch sector performance" });
    }
  });

  app.post("/api/sectors/performance", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const performanceData = insertSectorPerformanceSchema.parse(req.body);
      const performance = await storage.createSectorPerformance(performanceData);
      res.status(201).json(performance);
    } catch (error) {
      console.error("Error creating sector performance:", error);
      res.status(400).json({ error: "Invalid sector performance data" });
    }
  });

  // Sector Predictions Routes
  app.get("/api/sectors/predictions", async (req, res) => {
    try {
      const sector = req.query.sector?.toString() || "";
      const date = req.query.date ? new Date(req.query.date.toString()) : undefined;
      
      const predictions = await storage.getSectorPredictions(sector, date);
      res.json(predictions);
    } catch (error) {
      console.error("Error fetching sector predictions:", error);
      res.status(500).json({ error: "Failed to fetch sector predictions" });
    }
  });

  app.post("/api/sectors/predictions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const predictionData = insertSectorPredictionSchema.parse(req.body);
      const prediction = await storage.createSectorPrediction(predictionData);
      res.status(201).json(prediction);
    } catch (error) {
      console.error("Error creating sector prediction:", error);
      res.status(400).json({ error: "Invalid sector prediction data" });
    }
  });

  // Watchlist Routes
  app.get("/api/watchlists", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const watchlists = await storage.getWatchlistsByUser(req.user!.id);
      res.json(watchlists);
    } catch (error) {
      console.error("Error fetching watchlists:", error);
      res.status(500).json({ error: "Failed to fetch watchlists" });
    }
  });

  app.get("/api/watchlists/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const id = parseInt(req.params.id);
      const watchlist = await storage.getWatchlist(id);

      if (!watchlist) {
        return res.status(404).json({ error: "Watchlist not found" });
      }

      // Check if the watchlist belongs to the current user
      if (watchlist.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access to watchlist" });
      }

      res.json(watchlist);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      res.status(500).json({ error: "Failed to fetch watchlist" });
    }
  });

  app.post("/api/watchlists", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const watchlistData = insertWatchlistSchema.parse({
        ...req.body,
        userId: req.user!.id  // Ensure userId is set to current user
      });
      
      const watchlist = await storage.createWatchlist(watchlistData);
      res.status(201).json(watchlist);
    } catch (error) {
      console.error("Error creating watchlist:", error);
      res.status(400).json({ error: "Invalid watchlist data" });
    }
  });

  // Watchlist Items Routes
  app.get("/api/watchlists/:watchlistId/items", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const watchlistId = parseInt(req.params.watchlistId);
      const watchlist = await storage.getWatchlist(watchlistId);
      
      if (!watchlist) {
        return res.status(404).json({ error: "Watchlist not found" });
      }

      // Check if the watchlist belongs to the current user
      if (watchlist.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access to watchlist" });
      }

      const items = await storage.getWatchlistItems(watchlistId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching watchlist items:", error);
      res.status(500).json({ error: "Failed to fetch watchlist items" });
    }
  });

  app.post("/api/watchlists/:watchlistId/items", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const watchlistId = parseInt(req.params.watchlistId);
      const watchlist = await storage.getWatchlist(watchlistId);
      
      if (!watchlist) {
        return res.status(404).json({ error: "Watchlist not found" });
      }

      // Check if the watchlist belongs to the current user
      if (watchlist.userId !== req.user!.id) {
        return res.status(403).json({ error: "Unauthorized access to watchlist" });
      }

      const itemData = insertWatchlistItemSchema.parse({
        ...req.body,
        watchlistId
      });
      
      const item = await storage.createWatchlistItem(itemData);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error adding item to watchlist:", error);
      res.status(400).json({ error: "Invalid watchlist item data" });
    }
  });

  app.delete("/api/watchlists/items/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const id = parseInt(req.params.id);
      await storage.deleteWatchlistItem(id);
      res.sendStatus(204);
    } catch (error) {
      console.error("Error deleting watchlist item:", error);
      res.status(500).json({ error: "Failed to delete watchlist item" });
    }
  });

  // AI Stock Overview - AI-generated stock analysis
  app.get("/api/stock-overview", async (req, res) => {
    try {
      const axios = await import('axios');
      const { HfInference } = await import('@huggingface/inference');
      
      // Get stock symbol and country
      const symbol = (req.query.symbol?.toString() || '').toUpperCase();
      const country = (req.query.country?.toString() || 'US').toUpperCase();
      
      if (!symbol) {
        return res.status(400).json({ error: "Stock symbol is required" });
      }
      
      // Initialize Hugging Face client
      const hf = new HfInference(process.env.HUGGINGFACE_API_KEY);
      
      // 1. Fetch stock data from Alpha Vantage
      const stockDataResponse = await axios.default.get(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${process.env.ALPHAVANTAGE_API_KEY}`
      );
      
      // 2. Fetch company overview from Alpha Vantage
      const companyOverviewResponse = await axios.default.get(
        `https://www.alphavantage.co/query?function=OVERVIEW&symbol=${symbol}&apikey=${process.env.ALPHAVANTAGE_API_KEY}`
      );
      
      // 3. Fetch recent news about the company
      const newsResponse = await axios.default.get(
        `https://newsapi.org/v2/everything?q=${symbol}&sortBy=publishedAt&apiKey=${process.env.NEWS_API_KEY}&pageSize=5`
      );
      
      // 4. Get Cubin Scale data for economic context
      const cubinResponse = await axios.default.get(
        `http://localhost:5000/api/cubin-scale?country=${country}`
      );
      
      // Extract data
      const stockQuote = stockDataResponse.data?.['Global Quote'] || {};
      const companyData = companyOverviewResponse.data || {};
      const newsArticles = newsResponse.data?.articles || [];
      const cubinData = cubinResponse.data || {};
      
      // Format news for AI input
      const newsText = newsArticles.map((article: any, index: number) => 
        `News ${index + 1}: ${article.title}. ${article.description || ""}`
      ).join("\n");
      
      // Create prompt for AI analysis
      const prompt = `
As a financial analyst, provide a concise investment overview of ${companyData.Name || symbol} based on the following data:

Company Information:
- Symbol: ${symbol}
- Sector: ${companyData.Sector || "Unknown"}
- Industry: ${companyData.Industry || "Unknown"}
- Market Cap: ${companyData.MarketCapitalization || "Unknown"}
- PE Ratio: ${companyData.PERatio || "Unknown"}
- Dividend Yield: ${companyData.DividendYield || "Unknown"}
- 52-Week Range: ${companyData["52WeekLow"] || "?"} - ${companyData["52WeekHigh"] || "?"}

Current Stock Performance:
- Current Price: ${stockQuote["05. price"] || "Unknown"}
- Change: ${stockQuote["09. change"] || "0"} (${stockQuote["10. change percent"] || "0%"})
- Volume: ${stockQuote["06. volume"] || "Unknown"}

Recent News:
${newsText}

Economic Context (Cubin Scale - Score: ${cubinData.score}/8):
${cubinData.summary || "Economic data not available"}

Based on this data, provide:
1. A brief overview of the company's current position (2-3 sentences)
2. Analysis of recent price movements and what might be causing them (2-3 sentences)
3. Key risk factors to consider (1-2 sentences)
4. Investment recommendation considering the current Cubin Scale economic outlook (1-2 sentences)
`;

      // Use HuggingFace AI to generate analysis
      const aiResponse = await hf.textGeneration({
        model: "databricks/dolly-v2-3b",
        inputs: prompt,
        parameters: {
          max_length: 500,
          temperature: 0.7
        }
      });
      
      // Format and return response
      const analysis = aiResponse.generated_text || "Unable to generate analysis";
      
      res.json({
        symbol,
        companyName: companyData.Name || symbol,
        sector: companyData.Sector || "Unknown",
        currentPrice: stockQuote["05. price"] || "Unknown",
        priceChange: stockQuote["09. change"] || "0",
        percentChange: stockQuote["10. change percent"] || "0%",
        economicContext: {
          cubinScore: cubinData.score,
          economicSummary: cubinData.summary
        },
        latestNews: newsArticles.slice(0, 3).map((article: any) => ({
          title: article.title,
          url: article.url,
          date: article.publishedAt
        })),
        aiAnalysis: analysis,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating AI stock overview:", error);
      res.status(500).json({ 
        error: "Failed to generate AI stock overview",
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Cubin Scale - Economic Prediction API (publicly accessible without authentication)
  app.get("/api/cubin-scale", async (req, res) => {
    try {
      const axios = await import('axios');
      const { HfInference } = await import('@huggingface/inference');
      
      // Initialize Hugging Face client
      const hf = new HfInference(process.env.HUGGINGFACE_API_KEY);
      
      // Get country for analysis (default to US if not specified)
      const country = (req.query.country?.toString() || 'US').toUpperCase();
      
      // 1. Fetch GDP data from Alpha Vantage
      const gdpResponse = await axios.default.get(
        `https://www.alphavantage.co/query?function=REAL_GDP&interval=quarterly&apikey=${process.env.ALPHAVANTAGE_API_KEY}`
      );
      
      // 2. Fetch News articles related to economy
      const newsResponse = await axios.default.get(
        `https://newsapi.org/v2/everything?q=economy+${country}&sortBy=publishedAt&apiKey=${process.env.NEWS_API_KEY}&pageSize=10`
      );
      
      // 3. Fetch Stock Market data
      const marketResponse = await axios.default.get(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=SPY&apikey=${process.env.ALPHAVANTAGE_API_KEY}`
      );
      
      // Data processing
      // Extract GDP growth rate from last few quarters
      const gdpData = gdpResponse.data?.data || [];
      const recentGDP = gdpData.slice(0, 4); // Last 4 quarters
      const gdpGrowthRate = recentGDP.length > 1 
        ? ((parseFloat(recentGDP[0].value) / parseFloat(recentGDP[1].value)) - 1) * 100 
        : 0;
      
      // Process news sentiment
      const newsArticles = newsResponse.data?.articles || [];
      let newsText = newsArticles.map((article: any) => article.title + ". " + (article.description || "")).join(" ");
      
      // Get market performance
      const marketData = marketResponse.data?.['Global Quote'] || {};
      const marketChangePercent = parseFloat((marketData?.['10. change percent'] || "0%").replace('%', ''));
      
      // AI Analysis with HuggingFace
      let aiSentiment = { label: "neutral", score: 0.5 };
      if (newsText) {
        try {
          // Truncate if too long for the model
          if (newsText.length > 2000) {
            newsText = newsText.substring(0, 2000);
          }
          
          const sentimentResponse = await hf.textClassification({
            model: "distilbert-base-uncased-finetuned-sst-2-english",
            inputs: newsText,
          });
          
          // Extract the first result or use default
          if (Array.isArray(sentimentResponse) && sentimentResponse.length > 0) {
            aiSentiment = {
              label: sentimentResponse[0]?.label || "neutral",
              score: sentimentResponse[0]?.score || 0.5
            };
          }
        } catch (error) {
          console.error("Error with AI sentiment analysis:", error);
        }
      }
      
      // Calculate Cubin Scale score (1-8)
      // Factors and their weights:
      // - GDP Growth: 30%
      // - News Sentiment: 25%
      // - Market Performance: 25%
      // - AI Prediction: 20%
      
      // Normalize GDP growth to 0-1 range (-2% to +5% range)
      const gdpNormalized = Math.max(0, Math.min(1, (gdpGrowthRate + 2) / 7));
      
      // Normalize market performance to 0-1 range (-5% to +5% range)
      const marketNormalized = Math.max(0, Math.min(1, (marketChangePercent + 5) / 10));
      
      // News sentiment is already 0-1 if positive, need to adjust if model returns different format
      const newsSentiment = aiSentiment.label === "POSITIVE" ? aiSentiment.score : 1 - aiSentiment.score;
      
      // AI prediction weight (assuming 0-1 range from sentiment analysis)
      const aiPredictionWeight = aiSentiment.label === "POSITIVE" ? aiSentiment.score : 1 - aiSentiment.score;
      
      // Calculate weighted average
      const weightedScore = 
        (gdpNormalized * 0.3) + 
        (newsSentiment * 0.25) + 
        (marketNormalized * 0.25) + 
        (aiPredictionWeight * 0.2);
      
      // Convert to 1-8 scale
      const cubinScore = Math.round(1 + weightedScore * 7);
      
      // Generate prediction summary based on the score
      let summary = "";
      let recommendations = [];
      
      switch(cubinScore) {
        case 1:
          summary = "Severe economic contraction likely. High risk environment.";
          recommendations = ["Focus on capital preservation", "Consider defensive assets", "Reduce exposure to growth stocks"];
          break;
        case 2:
          summary = "Economic downturn probable. Caution advised.";
          recommendations = ["Increase cash positions", "Look for value opportunities", "Consider short-term government bonds"];
          break;
        case 3:
          summary = "Economic slowdown expected. Monitor carefully.";
          recommendations = ["Diversify portfolio", "Focus on quality stocks with strong balance sheets", "Gradual repositioning"];
          break;
        case 4:
          summary = "Neutral economic outlook with mild growth.";
          recommendations = ["Balanced allocation", "Both growth and value investments", "Average cash positions"];
          break;
        case 5:
          summary = "Moderate economic growth expected.";
          recommendations = ["Tilt toward growth investments", "Reduce fixed-income duration", "Consider emerging markets"];
          break;
        case 6:
          summary = "Strong economic growth indicators. Positive outlook.";
          recommendations = ["Overweight equities", "Focus on cyclical sectors", "Consider small-cap opportunities"];
          break;
        case 7:
          summary = "Very strong economic expansion signals.";
          recommendations = ["Aggressive growth positioning", "Commodity exposure for inflation protection", "Reduce bond allocations"];
          break;
        case 8:
          summary = "Exceptional economic growth potential. Possible overheating.";
          recommendations = ["Maximum growth exposure", "Inflation hedges", "Watch for potential market euphoria"];
          break;
        default:
          summary = "Balanced economic conditions expected.";
          recommendations = ["Maintain diversified portfolio", "Equal weight across asset classes", "Regular rebalancing"];
      }
      
      // Create response object
      const cubinScaleData: CubinScaleData = {
        score: cubinScore,
        confidence: Math.min(0.95, Math.max(0.4, weightedScore)),
        factors: {
          gdpImpact: parseFloat((gdpNormalized * 8).toFixed(1)),
          newsImpact: parseFloat((newsSentiment * 8).toFixed(1)),
          marketImpact: parseFloat((marketNormalized * 8).toFixed(1)),
          aiPrediction: parseFloat((aiPredictionWeight * 8).toFixed(1))
        },
        summary,
        recommendations,
        timestamp: new Date().toISOString()
      };
      
      res.json(cubinScaleData);
    } catch (error) {
      console.error("Error generating Cubin Scale prediction:", error);
      res.status(500).json({ 
        error: "Failed to generate Cubin Scale prediction",
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  return httpServer;
}