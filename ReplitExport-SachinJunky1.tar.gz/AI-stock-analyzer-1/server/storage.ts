import {
  User, InsertUser, users,
  Stock, InsertStock, stocks,
  StockPrice, InsertStockPrice, stockPrices,
  EconomicIndicator, InsertEconomicIndicator, economicIndicators,
  EconomicData, InsertEconomicData, economicData,
  SectorPerformance, InsertSectorPerformance, sectorPerformance,
  Watchlist, InsertWatchlist, watchlists,
  WatchlistItem, InsertWatchlistItem, watchlistItems,
  SectorPrediction, InsertSectorPrediction, sectorPredictions
} from "@shared/schema";
import { Store } from "express-session";
import { db } from "./db";
import { eq, and, sql, between, gte, lte, desc } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  
  // Stock operations
  getStock(id: number): Promise<Stock | undefined>;
  getStockBySymbol(symbol: string): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;
  getStocks(): Promise<Stock[]>;
  getStocksBySector(sector: string): Promise<Stock[]>;
  
  // Stock price operations
  getStockPrices(stockId: number, startDate?: Date, endDate?: Date): Promise<StockPrice[]>;
  createStockPrice(stockPrice: InsertStockPrice): Promise<StockPrice>;
  
  // Economic indicator operations
  getEconomicIndicator(id: number): Promise<EconomicIndicator | undefined>;
  getEconomicIndicatorByName(name: string): Promise<EconomicIndicator | undefined>;
  createEconomicIndicator(indicator: InsertEconomicIndicator): Promise<EconomicIndicator>;
  getEconomicIndicators(): Promise<EconomicIndicator[]>;
  getEconomicIndicatorsByCategory(category: string): Promise<EconomicIndicator[]>;
  
  // Economic data operations
  getEconomicData(indicatorId: number, startDate?: Date, endDate?: Date): Promise<EconomicData[]>;
  createEconomicData(data: InsertEconomicData): Promise<EconomicData>;
  
  // Sector performance operations
  getSectorPerformance(sector: string, startDate?: Date, endDate?: Date): Promise<SectorPerformance[]>;
  getAllSectorPerformance(date?: Date): Promise<SectorPerformance[]>;
  createSectorPerformance(data: InsertSectorPerformance): Promise<SectorPerformance>;
  
  // Sector predictions operations
  getSectorPredictions(sector: string, date?: Date): Promise<SectorPrediction[]>;
  createSectorPrediction(prediction: InsertSectorPrediction): Promise<SectorPrediction>;
  
  // Watchlist operations
  getWatchlist(id: number): Promise<Watchlist | undefined>;
  getWatchlistsByUser(userId: number): Promise<Watchlist[]>;
  createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  
  // Watchlist items operations
  getWatchlistItems(watchlistId: number): Promise<WatchlistItem[]>;
  createWatchlistItem(item: InsertWatchlistItem): Promise<WatchlistItem>;
  deleteWatchlistItem(id: number): Promise<void>;
  
  sessionStore: Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Stock operations
  async getStock(id: number): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.id, id));
    return stock;
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.symbol, symbol));
    return stock;
  }

  async createStock(stock: InsertStock): Promise<Stock> {
    const [newStock] = await db.insert(stocks).values(stock).returning();
    return newStock;
  }

  async getStocks(): Promise<Stock[]> {
    return await db.select().from(stocks);
  }

  async getStocksBySector(sector: string): Promise<Stock[]> {
    return await db.select().from(stocks).where(eq(stocks.sector, sector));
  }

  // Stock price operations
  async getStockPrices(stockId: number, startDate?: Date, endDate?: Date): Promise<StockPrice[]> {
    let query = db.select().from(stockPrices).where(eq(stockPrices.stockId, stockId));
    
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(stockPrices.date, startDate.toISOString().split('T')[0]),
          lte(stockPrices.date, endDate.toISOString().split('T')[0])
        )
      );
    } else if (startDate) {
      query = query.where(gte(stockPrices.date, startDate.toISOString().split('T')[0]));
    } else if (endDate) {
      query = query.where(lte(stockPrices.date, endDate.toISOString().split('T')[0]));
    }
    
    return await query.orderBy(stockPrices.date);
  }

  async createStockPrice(stockPrice: InsertStockPrice): Promise<StockPrice> {
    const [newStockPrice] = await db.insert(stockPrices).values(stockPrice).returning();
    return newStockPrice;
  }

  // Economic indicator operations
  async getEconomicIndicator(id: number): Promise<EconomicIndicator | undefined> {
    const [indicator] = await db.select().from(economicIndicators).where(eq(economicIndicators.id, id));
    return indicator;
  }

  async getEconomicIndicatorByName(name: string): Promise<EconomicIndicator | undefined> {
    const [indicator] = await db.select().from(economicIndicators).where(eq(economicIndicators.name, name));
    return indicator;
  }

  async createEconomicIndicator(indicator: InsertEconomicIndicator): Promise<EconomicIndicator> {
    const [newIndicator] = await db.insert(economicIndicators).values(indicator).returning();
    return newIndicator;
  }

  async getEconomicIndicators(): Promise<EconomicIndicator[]> {
    return await db.select().from(economicIndicators);
  }

  async getEconomicIndicatorsByCategory(category: string): Promise<EconomicIndicator[]> {
    return await db.select().from(economicIndicators).where(eq(economicIndicators.category, category));
  }

  // Economic data operations
  async getEconomicData(indicatorId: number, startDate?: Date, endDate?: Date): Promise<EconomicData[]> {
    let query = db.select().from(economicData).where(eq(economicData.indicatorId, indicatorId));
    
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(economicData.date, startDate.toISOString().split('T')[0]),
          lte(economicData.date, endDate.toISOString().split('T')[0])
        )
      );
    } else if (startDate) {
      query = query.where(gte(economicData.date, startDate.toISOString().split('T')[0]));
    } else if (endDate) {
      query = query.where(lte(economicData.date, endDate.toISOString().split('T')[0]));
    }
    
    return await query.orderBy(economicData.date);
  }

  async createEconomicData(data: InsertEconomicData): Promise<EconomicData> {
    const [newData] = await db.insert(economicData).values(data).returning();
    return newData;
  }

  // Sector performance operations
  async getSectorPerformance(sector: string, startDate?: Date, endDate?: Date): Promise<SectorPerformance[]> {
    let query = db.select().from(sectorPerformance).where(eq(sectorPerformance.sector, sector));
    
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(sectorPerformance.date, startDate.toISOString().split('T')[0]),
          lte(sectorPerformance.date, endDate.toISOString().split('T')[0])
        )
      );
    } else if (startDate) {
      query = query.where(gte(sectorPerformance.date, startDate.toISOString().split('T')[0]));
    } else if (endDate) {
      query = query.where(lte(sectorPerformance.date, endDate.toISOString().split('T')[0]));
    }
    
    return await query.orderBy(sectorPerformance.date);
  }

  async getAllSectorPerformance(date?: Date): Promise<SectorPerformance[]> {
    if (date) {
      return await db
        .select()
        .from(sectorPerformance)
        .where(eq(sectorPerformance.date, date.toISOString().split('T')[0]))
        .orderBy(sectorPerformance.sector);
    } else {
      // Get the latest data for each sector
      const latestDateSubquery = db
        .select({ maxDate: sql`MAX(${sectorPerformance.date})`.as('maxDate') })
        .from(sectorPerformance)
        .as('latest_date');
      
      const latestDate = await db.select({ maxDate: latestDateSubquery.maxDate }).from(latestDateSubquery);
      
      if (latestDate.length > 0 && latestDate[0].maxDate) {
        return await db
          .select()
          .from(sectorPerformance)
          .where(eq(sectorPerformance.date, latestDate[0].maxDate))
          .orderBy(sectorPerformance.sector);
      }
      
      return [];
    }
  }

  async createSectorPerformance(data: InsertSectorPerformance): Promise<SectorPerformance> {
    const [newData] = await db.insert(sectorPerformance).values(data).returning();
    return newData;
  }
  
  // Sector predictions operations
  async getSectorPredictions(sector: string, date?: Date): Promise<SectorPrediction[]> {
    let query = db.select().from(sectorPredictions);
    
    if (sector) {
      query = query.where(eq(sectorPredictions.sector, sector));
    }
    
    if (date) {
      query = query.where(eq(sectorPredictions.date, date.toISOString().split('T')[0]));
    }
    
    return await query.orderBy(desc(sectorPredictions.score));
  }
  
  async createSectorPrediction(prediction: InsertSectorPrediction): Promise<SectorPrediction> {
    const [newPrediction] = await db.insert(sectorPredictions).values(prediction).returning();
    return newPrediction;
  }

  // Watchlist operations
  async getWatchlist(id: number): Promise<Watchlist | undefined> {
    const [watchlist] = await db.select().from(watchlists).where(eq(watchlists.id, id));
    return watchlist;
  }

  async getWatchlistsByUser(userId: number): Promise<Watchlist[]> {
    return await db.select().from(watchlists).where(eq(watchlists.userId, userId));
  }

  async createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist> {
    const [newWatchlist] = await db.insert(watchlists).values(watchlist).returning();
    return newWatchlist;
  }

  // Watchlist items operations
  async getWatchlistItems(watchlistId: number): Promise<WatchlistItem[]> {
    return await db.select().from(watchlistItems).where(eq(watchlistItems.watchlistId, watchlistId));
  }

  async createWatchlistItem(item: InsertWatchlistItem): Promise<WatchlistItem> {
    const [newItem] = await db.insert(watchlistItems).values(item).returning();
    return newItem;
  }

  async deleteWatchlistItem(id: number): Promise<void> {
    await db.delete(watchlistItems).where(eq(watchlistItems.id, id));
  }
}

export const storage = new DatabaseStorage();