import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { Separator } from "@/components/ui/separator";
import { RefreshCw, AlertTriangle, TrendingUp, TrendingDown, BarChart3, Newspaper, LineChart, Brain } from "lucide-react";

// Export CubinScaleData interface to match the server's type
export interface CubinScaleData {
  score: number;
  confidence: number;
  factors: {
    gdpImpact: number;
    newsImpact: number;
    marketImpact: number;
    aiPrediction: number;
  };
  summary: string;
  recommendations: string[];
  timestamp: string;
}

const COUNTRIES = [
  { code: "US", name: "United States" },
  { code: "GB", name: "United Kingdom" },
  { code: "DE", name: "Germany" },
  { code: "JP", name: "Japan" },
  { code: "CN", name: "China" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
  { code: "FR", name: "France" },
  { code: "IN", name: "India" },
  { code: "BR", name: "Brazil" },
];

export function CubinScale() {
  const [country, setCountry] = React.useState("US");
  const [activeTab, setActiveTab] = React.useState("overview");
  
  const {
    data: cubinData,
    isLoading,
    isError,
    error,
    refetch,
    isRefetching
  } = useQuery({
    queryKey: ["/api/cubin-scale", { country }],
    queryFn: async () => {
      return await apiRequest<CubinScaleData>(`/api/cubin-scale?country=${country}`);
    }
  });
  
  // Function to determine score color based on value
  const getScoreColor = (score: number) => {
    if (score <= 2) return "bg-red-500 text-white";
    if (score <= 4) return "bg-yellow-500 text-white";
    if (score <= 6) return "bg-green-500 text-white";
    return "bg-blue-500 text-white";
  };
  
  // Function to determine factor icon and color
  const getFactorDetails = (name: string, value: number) => {
    let icon;
    let color;
    
    // Determine icon based on factor name
    switch (name) {
      case "gdpImpact":
        icon = <BarChart3 className="h-5 w-5" />;
        break;
      case "newsImpact":
        icon = <Newspaper className="h-5 w-5" />;
        break;
      case "marketImpact":
        icon = <LineChart className="h-5 w-5" />;
        break;
      case "aiPrediction":
        icon = <Brain className="h-5 w-5" />;
        break;
      default:
        icon = <TrendingUp className="h-5 w-5" />;
    }
    
    // Determine color based on value
    if (value <= 3) color = "text-red-500";
    else if (value <= 5) color = "text-yellow-500";
    else color = "text-green-500";
    
    return { icon, color };
  };
  
  // Format factor label from camelCase
  const formatFactorLabel = (factorName: string) => {
    const formattedName = factorName
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase());
    
    return formattedName;
  };
  
  if (isError) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Cubin Scale Economic Predictor</CardTitle>
          <CardDescription>Economic Health Score (1-8)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8 text-center">
            <div>
              <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Error Loading Cubin Scale</h3>
              <p className="text-muted-foreground mb-4">
                {(error as Error)?.message || "An error occurred while fetching the economic data."}
              </p>
              <Button onClick={() => refetch()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="mb-6">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Cubin Scale Economic Predictor</CardTitle>
            <CardDescription>Economic Health Score (1-8) | {new Date().toLocaleDateString()}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={country} onValueChange={setCountry}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Country" />
              </SelectTrigger>
              <SelectContent>
                {COUNTRIES.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              size="icon"
              onClick={() => refetch()}
              disabled={isLoading || isRefetching}
            >
              <RefreshCw className={`h-4 w-4 ${isRefetching ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading || !cubinData ? (
          <div className="py-8 flex items-center justify-center">
            <div className="text-center">
              <RefreshCw className="h-8 w-8 mx-auto mb-4 animate-spin text-primary" />
              <p>Analyzing economic data...</p>
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-col md:flex-row gap-6 mb-6">
              <div className="flex-1 flex flex-col items-center justify-center p-6 bg-muted rounded-lg text-center">
                <div className={`flex items-center justify-center h-24 w-24 rounded-full text-4xl font-bold mb-4 ${getScoreColor(cubinData.score)}`}>
                  {cubinData.score}
                </div>
                <h3 className="text-lg font-semibold mb-2">Current Cubin Score</h3>
                <p className="text-sm text-muted-foreground">
                  Confidence: {Math.round(cubinData.confidence * 100)}%
                </p>
              </div>
              
              <div className="flex-1">
                <div className="mb-4">
                  <h3 className="text-lg font-semibold mb-2">Summary</h3>
                  <p>{cubinData.summary}</p>
                </div>
                <h3 className="text-lg font-semibold mb-2">Key Recommendations</h3>
                <ul className="space-y-1">
                  {cubinData.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start">
                      <div className="mr-2 mt-0.5 text-primary">•</div>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="overview">Contributing Factors</TabsTrigger>
                <TabsTrigger value="details">Detailed Analysis</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(cubinData.factors).map(([factor, value]) => {
                    const { icon, color } = getFactorDetails(factor, value);
                    return (
                      <div key={factor} className="flex items-center p-3 border rounded-md">
                        <div className={`mr-3 ${color}`}>
                          {icon}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{formatFactorLabel(factor)}</p>
                          <div className="w-full bg-muted rounded-full h-2 mt-1">
                            <div 
                              className={value <= 3 ? "bg-red-500" : value <= 5 ? "bg-yellow-500" : "bg-green-500"}
                              style={{ width: `${(value / 8) * 100}%`, height: "100%", borderRadius: "9999px" }}
                            ></div>
                          </div>
                        </div>
                        <Badge variant="outline" className={color}>
                          {value.toFixed(1)}/8
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              </TabsContent>
              
              <TabsContent value="details" className="pt-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Economic Cycle Position</h3>
                    <div className="relative h-8 bg-muted rounded-full overflow-hidden">
                      <div className="absolute inset-0 flex">
                        <div className="bg-red-400 flex-1 flex items-center justify-center text-xs font-medium text-white">Recession</div>
                        <div className="bg-yellow-400 flex-1 flex items-center justify-center text-xs font-medium text-white">Recovery</div>
                        <div className="bg-green-400 flex-1 flex items-center justify-center text-xs font-medium text-white">Expansion</div>
                        <div className="bg-blue-400 flex-1 flex items-center justify-center text-xs font-medium text-white">Peak</div>
                      </div>
                      <div 
                        className="absolute top-0 h-full w-1 bg-black"
                        style={{ left: `${(cubinData.score / 8) * 100}%`, transform: "translateX(-50%)" }}
                      ></div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Historical Context</h3>
                    <p className="mb-4 text-sm text-muted-foreground">
                      The Cubin Scale is calibrated against historical economic cycles:
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p><strong>1-2:</strong> Comparable to 2008 Financial Crisis</p>
                        <p><strong>3-4:</strong> Comparable to 2001-2002 Recession</p>
                      </div>
                      <div>
                        <p><strong>5-6:</strong> Comparable to 2014-2018 Expansion</p>
                        <p><strong>7-8:</strong> Comparable to 1990s Tech Boom</p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">AI-Enhanced Methodology</h3>
                    <p className="text-sm text-muted-foreground">
                      The Cubin Scale combines traditional economic indicators with AI-powered sentiment analysis and machine learning predictions to provide a comprehensive view of economic health.
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground border-t pt-4">
        <p>Last updated: {cubinData?.timestamp ? new Date(cubinData.timestamp).toLocaleString() : "Not available"}</p>
      </CardFooter>
    </Card>
  );
}