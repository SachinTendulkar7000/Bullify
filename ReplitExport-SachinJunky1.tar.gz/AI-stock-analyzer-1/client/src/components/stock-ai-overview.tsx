import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  RefreshCw, 
  AlertTriangle, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  BookOpen,
  ExternalLink
} from "lucide-react";

// Define StockOverview response type
export interface StockAiOverviewData {
  symbol: string;
  companyName: string;
  sector: string;
  currentPrice: string;
  priceChange: string;
  percentChange: string;
  economicContext: {
    cubinScore: number;
    economicSummary: string;
  };
  latestNews: Array<{
    title: string;
    url: string;
    date: string;
  }>;
  aiAnalysis: string;
  timestamp: string;
}

export function StockAiOverview() {
  const [symbol, setSymbol] = React.useState("");
  const [searchSymbol, setSearchSymbol] = React.useState("");
  const { toast } = useToast();
  
  const {
    data: stockData,
    isLoading,
    isError,
    error,
    refetch,
    isRefetching,
    isFetched
  } = useQuery({
    queryKey: ["/api/stock-overview", { symbol: searchSymbol }],
    queryFn: async () => {
      if (!searchSymbol) return null;
      return await apiRequest<StockAiOverviewData>(`/api/stock-overview?symbol=${searchSymbol}`);
    },
    enabled: !!searchSymbol // Only run the query if there's a search symbol
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol.trim()) {
      toast({
        title: "Symbol required",
        description: "Please enter a stock symbol to analyze",
        variant: "destructive"
      });
      return;
    }
    setSearchSymbol(symbol.trim());
  };
  
  const getPriceChangeColor = (change: string) => {
    const value = parseFloat(change);
    if (isNaN(value)) return "text-muted-foreground";
    return value < 0 ? "text-red-500" : value > 0 ? "text-green-500" : "text-muted-foreground";
  };
  
  const formatAnalysis = (text: string) => {
    // Split analysis into paragraphs
    return text.split('\n\n').filter(p => p.trim().length > 0);
  };
  
  if (isError) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>AI Stock Overview</CardTitle>
          <CardDescription>Comprehensive AI-generated stock analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8 text-center">
            <div>
              <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Error Loading Stock Analysis</h3>
              <p className="text-muted-foreground mb-4">
                {(error as Error)?.message || "An error occurred while generating the stock analysis."}
              </p>
              <Button onClick={() => refetch()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="mb-6">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>AI Stock Overview</CardTitle>
            <CardDescription>AI-powered analysis combining news, financial data and economic indicators</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSearch} className="flex gap-2 mb-6">
          <div className="flex-1">
            <Input
              type="text"
              placeholder="Enter stock symbol (e.g., AAPL, MSFT, TSLA)"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            />
          </div>
          <Button 
            type="submit" 
            disabled={isLoading || isRefetching}
          >
            {isLoading || isRefetching ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Search className="h-4 w-4 mr-2" />
            )}
            Analyze
          </Button>
        </form>
        
        {!searchSymbol && !isLoading && !isFetched ? (
          <div className="py-12 text-center">
            <BarChart3 className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-medium mb-2">Enter a stock symbol to analyze</h3>
            <p className="text-muted-foreground">
              Get AI-powered insights combining Cubin Scale economic data, company news, and financial metrics.
            </p>
          </div>
        ) : isLoading || isRefetching ? (
          <div className="py-16 flex items-center justify-center">
            <div className="text-center">
              <RefreshCw className="h-10 w-10 mx-auto mb-4 animate-spin text-primary" />
              <p className="text-lg">Generating AI analysis for {searchSymbol}...</p>
              <p className="text-sm text-muted-foreground mt-2">
                This may take a moment as we analyze company data, news, and economic indicators.
              </p>
            </div>
          </div>
        ) : stockData ? (
          <div>
            <div className="flex flex-col md:flex-row gap-6 mb-6">
              <div className="w-full md:w-1/3 bg-muted p-6 rounded-lg">
                <div className="mb-4">
                  <h3 className="text-2xl font-bold">{stockData.companyName}</h3>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="mr-2">{stockData.symbol}</Badge>
                    <span className="text-sm text-muted-foreground">{stockData.sector}</span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="text-3xl font-bold">${stockData.currentPrice}</div>
                  <div className={`flex items-center mt-1 ${getPriceChangeColor(stockData.priceChange)}`}>
                    {parseFloat(stockData.priceChange) >= 0 ? (
                      <TrendingUp className="h-4 w-4 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 mr-1" />
                    )}
                    <span>{stockData.priceChange} ({stockData.percentChange})</span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Economic Context</h4>
                  <div className="flex items-center mb-2">
                    <span className="text-sm">Cubin Scale: </span>
                    <Badge 
                      className="ml-2" 
                      variant={stockData.economicContext.cubinScore <= 3 ? "destructive" : 
                              stockData.economicContext.cubinScore >= 6 ? "default" : "secondary"}
                    >
                      {stockData.economicContext.cubinScore}/8
                    </Badge>
                  </div>
                  <p className="text-sm">{stockData.economicContext.economicSummary}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Latest News</h4>
                  <ul className="space-y-2">
                    {stockData.latestNews.map((news, index) => (
                      <li key={index} className="text-sm">
                        <a 
                          href={news.url} 
                          target="_blank" 
                          rel="noreferrer"
                          className="flex items-start hover:underline"
                        >
                          <ExternalLink className="h-3 w-3 mr-1 mt-1 flex-shrink-0" />
                          <span>{news.title}</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="flex-1">
                <div className="mb-4">
                  <div className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-2" />
                    <h3 className="text-xl font-bold">AI Analysis</h3>
                  </div>
                  <Separator className="my-3" />
                </div>
                
                <div className="space-y-4 text-sm">
                  {formatAnalysis(stockData.aiAnalysis).map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : isFetched && (
          <div className="py-12 text-center">
            <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-yellow-500" />
            <h3 className="text-lg font-medium mb-2">No data found for "{searchSymbol}"</h3>
            <p className="text-muted-foreground mb-4">
              We couldn't find any data for this symbol. Please check the symbol and try again.
            </p>
            <Button variant="outline" onClick={() => setSearchSymbol("")}>
              Try another symbol
            </Button>
          </div>
        )}
      </CardContent>
      {stockData && (
        <CardFooter className="text-xs text-muted-foreground border-t pt-4">
          <p>Last updated: {new Date(stockData.timestamp).toLocaleString()}</p>
        </CardFooter>
      )}
    </Card>
  );
}