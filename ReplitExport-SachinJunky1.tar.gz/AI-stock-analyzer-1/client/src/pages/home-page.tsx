import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Stock, SectorPerformance, EconomicIndicator } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3,
  LineChart,
  TrendingUp,
  Search,
  LogOut,
  PieChart,
  DollarSign,
  AreaChart,
  Bell,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  BookOpen
} from "lucide-react";
import { useDebounce } from "@/hooks/use-debounce";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { CubinScale } from "@/components/cubin-scale";
import { StockAiOverview } from "@/components/stock-ai-overview";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stockSearch, setStockSearch] = useState("");
  const debouncedSearch = useDebounce(stockSearch, 300);

  // Fetch stocks for comparison tool
  const { data: stocks = [] } = useQuery<Stock[]>({
    queryKey: ["/api/stocks", { search: debouncedSearch }],
  });

  // Fetch sector performance data for sector rotation predictor
  const { data: sectorPerformance = [] } = useQuery<SectorPerformance[]>({
    queryKey: ["/api/sectors/performance"],
  });

  // Fetch economic indicators for dashboard
  const { data: indicators = [] } = useQuery<EconomicIndicator[]>({
    queryKey: ["/api/indicators"],
  });

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-[250px] border-r flex flex-col">
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar>
              <AvatarFallback>{user?.username?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
            </Avatar>
            <span className="font-semibold">{user?.username}</span>
          </div>
          <Button variant="ghost" size="icon" onClick={() => logoutMutation.mutate()}>
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="px-2 py-4">
            <div className="mb-6">
              <h3 className="px-4 text-sm font-medium mb-2">TOOLS</h3>
              <div className="space-y-1">
                <Button 
                  variant={activeTab === "dashboard" ? "secondary" : "ghost"} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab("dashboard")}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
                <Button
                  variant={activeTab === "sectors" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("sectors")}
                >
                  <PieChart className="h-4 w-4 mr-2" />
                  Sector Rotation
                </Button>
                <Button
                  variant={activeTab === "indicators" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("indicators")}
                >
                  <LineChart className="h-4 w-4 mr-2" />
                  Economic Indicators
                </Button>
                <Button
                  variant={activeTab === "cubin" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("cubin")}
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Cubin Scale
                </Button>
                <Button
                  variant={activeTab === "comparison" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("comparison")}
                >
                  <AreaChart className="h-4 w-4 mr-2" />
                  Stock Comparison
                </Button>
                <Button
                  variant={activeTab === "ai-overview" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("ai-overview")}
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  AI Stock Overview
                </Button>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="px-4 text-sm font-medium mb-2">MY WATCHLISTS</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start">
                  <DollarSign className="h-4 w-4 mr-2" />
                  Tech Stocks
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <DollarSign className="h-4 w-4 mr-2" />
                  Energy Sector
                </Button>
                <Button variant="ghost" className="w-full justify-start flex items-center">
                  <Plus className="h-4 w-4 mr-2" />
                  <span>Create Watchlist</span>
                </Button>
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="p-4 border-b">
          <h1 className="text-2xl font-bold">Bullify Financial Analysis</h1>
        </div>
        
        <div className="flex-1 overflow-auto p-6">
          <Tabs defaultValue="cubin" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsContent value="dashboard" className="border-none p-0 mt-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">S&P 500</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">4,781.56</div>
                    <div className="flex items-center text-xs text-green-500">
                      <ArrowUpRight className="h-3 w-3 mr-1" />
                      <span>+1.2% today</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">NASDAQ</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">15,102.42</div>
                    <div className="flex items-center text-xs text-green-500">
                      <ArrowUpRight className="h-3 w-3 mr-1" />
                      <span>+0.9% today</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Dow Jones</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">39,806.75</div>
                    <div className="flex items-center text-xs text-red-500">
                      <ArrowDownRight className="h-3 w-3 mr-1" />
                      <span>-0.3% today</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Market Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] flex items-center justify-center bg-muted rounded-md">
                      <p className="text-muted-foreground">Interactive chart will appear here</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Performing Sectors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {sectorPerformance.length > 0 ? (
                        sectorPerformance.slice(0, 5).map((sector, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div className="font-medium">{sector.sector}</div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              +{sector.performance.toFixed(2)}%
                            </Badge>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-4 text-muted-foreground">
                          No sector data available
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Economic Indicators</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {indicators.length > 0 ? (
                        indicators.slice(0, 5).map((indicator, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <div className="font-medium">{indicator.name}</div>
                            <Badge variant="outline">
                              {indicator.category}
                            </Badge>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-4 text-muted-foreground">
                          No indicator data available
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Latest News</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="border-b pb-2">
                        <h3 className="font-medium">Fed Signals Rate Cut in September</h3>
                        <p className="text-sm text-muted-foreground">2 hours ago</p>
                      </div>
                      <div className="border-b pb-2">
                        <h3 className="font-medium">Tech Stocks Rally on Earnings</h3>
                        <p className="text-sm text-muted-foreground">4 hours ago</p>
                      </div>
                      <div className="border-b pb-2">
                        <h3 className="font-medium">Oil Prices Surge on Supply Concerns</h3>
                        <p className="text-sm text-muted-foreground">8 hours ago</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="sectors" className="border-none p-0 mt-0">
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Sector Rotation Predictor</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px] flex items-center justify-center bg-muted rounded-md">
                      <p className="text-muted-foreground">Sector rotation visualization will appear here</p>
                    </div>
                    <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
                      <div className="bg-muted p-4 rounded-md">
                        <h3 className="font-medium mb-2">Current Phase</h3>
                        <div className="text-xl font-bold">Early Expansion</div>
                        <p className="text-sm text-muted-foreground mt-1">Favors consumer discretionary and technology sectors</p>
                      </div>
                      <div className="bg-muted p-4 rounded-md">
                        <h3 className="font-medium mb-2">Top Performing</h3>
                        <div className="text-xl font-bold">Technology</div>
                        <p className="text-sm text-muted-foreground mt-1">+15.2% over last 3 months</p>
                      </div>
                      <div className="bg-muted p-4 rounded-md">
                        <h3 className="font-medium mb-2">Projected Next Phase</h3>
                        <div className="text-xl font-bold">Late Expansion</div>
                        <p className="text-sm text-muted-foreground mt-1">Expected in 3-6 months</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Sector Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Sample sectors */}
                      {['Technology', 'Healthcare', 'Financials', 'Consumer Discretionary', 'Energy', 'Materials', 'Utilities', 'Real Estate'].map((sector, index) => (
                        <div key={index} className="flex flex-col">
                          <div className="flex justify-between items-center mb-2">
                            <div className="font-medium">{sector}</div>
                            <Badge variant={index % 3 === 0 ? "default" : index % 3 === 1 ? "secondary" : "outline"}>
                              {index % 3 === 0 ? "Strong Buy" : index % 3 === 1 ? "Hold" : "Neutral"}
                            </Badge>
                          </div>
                          <div className="w-full bg-muted rounded-full h-3">
                            <div 
                              className={`rounded-full h-3 ${index % 3 === 0 ? 'bg-green-500' : index % 3 === 1 ? 'bg-yellow-500' : 'bg-blue-500'}`} 
                              style={{ width: `${20 + (index * 10) % 80}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="cubin" className="border-none p-0 mt-0">
              <CubinScale />
            </TabsContent>
            
            <TabsContent value="indicators" className="border-none p-0 mt-0">
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Economic Indicators Dashboard</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Inflation Rate (CPI)</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">3.2%</div>
                          <div className="flex items-center text-xs text-green-500">
                            <ArrowDownRight className="h-3 w-3 mr-1" />
                            <span>Decreased from 3.4%</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Unemployment Rate</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">3.9%</div>
                          <div className="flex items-center text-xs text-red-500">
                            <ArrowUpRight className="h-3 w-3 mr-1" />
                            <span>Increased from 3.7%</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Federal Funds Rate</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">5.25-5.50%</div>
                          <div className="flex items-center text-xs text-yellow-500">
                            <span>Unchanged since Jul 2023</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">GDP Growth Rate</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">2.1%</div>
                          <div className="flex items-center text-xs text-green-500">
                            <ArrowUpRight className="h-3 w-3 mr-1" />
                            <span>Increased from 1.9%</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <div className="h-[300px] flex items-center justify-center bg-muted rounded-md mb-6">
                      <p className="text-muted-foreground">Economic indicators comparison chart will appear here</p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium text-lg">Indicator Overview</h3>
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Indicator</th>
                            <th className="text-right py-2">Current</th>
                            <th className="text-right py-2">Previous</th>
                            <th className="text-right py-2">Forecast</th>
                            <th className="text-right py-2">Impact</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="py-3">Consumer Price Index (CPI)</td>
                            <td className="text-right">3.2%</td>
                            <td className="text-right">3.4%</td>
                            <td className="text-right">3.1%</td>
                            <td className="text-right"><Badge>High</Badge></td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3">Unemployment Rate</td>
                            <td className="text-right">3.9%</td>
                            <td className="text-right">3.7%</td>
                            <td className="text-right">3.8%</td>
                            <td className="text-right"><Badge>High</Badge></td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3">Retail Sales MoM</td>
                            <td className="text-right">0.7%</td>
                            <td className="text-right">0.3%</td>
                            <td className="text-right">0.4%</td>
                            <td className="text-right"><Badge variant="outline">Medium</Badge></td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3">Industrial Production</td>
                            <td className="text-right">0.2%</td>
                            <td className="text-right">0.1%</td>
                            <td className="text-right">0.3%</td>
                            <td className="text-right"><Badge variant="outline">Medium</Badge></td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3">Building Permits</td>
                            <td className="text-right">1.47M</td>
                            <td className="text-right">1.44M</td>
                            <td className="text-right">1.50M</td>
                            <td className="text-right"><Badge variant="secondary">Low</Badge></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="comparison" className="border-none p-0 mt-0">
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Stock Comparison Tool</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-6">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          value={stockSearch}
                          onChange={(e) => setStockSearch(e.target.value)}
                          placeholder="Search stocks, ETFs or indices..."
                          className="pl-9"
                        />
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="font-medium mb-3">Selected for Comparison</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge className="px-3 py-1 flex items-center gap-1">
                          AAPL <button className="ml-1 hover:bg-muted-foreground/10 rounded-full">×</button>
                        </Badge>
                        <Badge className="px-3 py-1 flex items-center gap-1">
                          MSFT <button className="ml-1 hover:bg-muted-foreground/10 rounded-full">×</button>
                        </Badge>
                        <Badge className="px-3 py-1 flex items-center gap-1">
                          GOOGL <button className="ml-1 hover:bg-muted-foreground/10 rounded-full">×</button>
                        </Badge>
                        <Button variant="outline" size="sm" className="rounded-full">
                          <Plus className="h-3 w-3 mr-1" />
                          Add
                        </Button>
                      </div>
                    </div>
                    
                    <div className="h-[300px] flex items-center justify-center bg-muted rounded-md mb-6">
                      <p className="text-muted-foreground">Stock comparison chart will appear here</p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium text-lg">Comparative Analysis</h3>
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Symbol</th>
                            <th className="text-right py-2">Price</th>
                            <th className="text-right py-2">Chg %</th>
                            <th className="text-right py-2">Market Cap</th>
                            <th className="text-right py-2">P/E Ratio</th>
                            <th className="text-right py-2">Div Yield</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="py-3 font-medium">AAPL</td>
                            <td className="text-right">$189.98</td>
                            <td className="text-right text-green-500">+1.23%</td>
                            <td className="text-right">$2.97T</td>
                            <td className="text-right">32.8</td>
                            <td className="text-right">0.5%</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 font-medium">MSFT</td>
                            <td className="text-right">$415.50</td>
                            <td className="text-right text-green-500">+0.78%</td>
                            <td className="text-right">$3.09T</td>
                            <td className="text-right">36.2</td>
                            <td className="text-right">0.7%</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 font-medium">GOOGL</td>
                            <td className="text-right">$159.92</td>
                            <td className="text-right text-red-500">-0.42%</td>
                            <td className="text-right">$2.01T</td>
                            <td className="text-right">27.5</td>
                            <td className="text-right">0.4%</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="ai-overview" className="border-none p-0 mt-0">
              <StockAiOverview />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}