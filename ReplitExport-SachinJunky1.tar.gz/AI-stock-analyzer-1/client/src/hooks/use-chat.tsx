import { useAuth } from "./use-auth";

// This component has been deprecated as we've migrated from chat to financial analysis tools
// The file is retained for compatibility but its functionality is no longer used

export function useChat(receiverId: number | null) {
  const { user } = useAuth();
  
  // Empty implementation - this hook is no longer used
  return { 
    messages: [], 
    sendMessage: () => {} 
  };
}
