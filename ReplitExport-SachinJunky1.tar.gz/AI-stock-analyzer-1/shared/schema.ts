import { pgTable, text, serial, integer, timestamp, real, date, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  avatarUrl: text("avatar_url"),
});

// Stock data
export const stocks = pgTable("stocks", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  industry: text("industry").notNull(),
  description: text("description"),
  marketCap: real("market_cap"),
  peRatio: real("pe_ratio"),
  dividendYield: real("dividend_yield"),
  beta: real("beta"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Historical price data
export const stockPrices = pgTable("stock_prices", {
  id: serial("id").primaryKey(),
  stockId: integer("stock_id").notNull(),
  date: date("date").notNull(),
  open: real("open").notNull(),
  high: real("high").notNull(),
  low: real("low").notNull(),
  close: real("close").notNull(),
  volume: integer("volume").notNull(),
});

// Economic indicators
export const economicIndicators = pgTable("economic_indicators", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(), // e.g., inflation, interest rates, GDP, unemployment
  description: text("description"),
  frequencyOfUpdate: text("frequency_of_update"), // e.g., daily, weekly, monthly, quarterly
  source: text("source"), // Data source
});

// Economic indicator data
export const economicData = pgTable("economic_data", {
  id: serial("id").primaryKey(),
  indicatorId: integer("indicator_id").notNull(),
  date: date("date").notNull(),
  value: real("value").notNull(),
  percentChange: real("percent_change"),
  notes: text("notes"),
});

// Sector performance tracker
export const sectorPerformance = pgTable("sector_performance", {
  id: serial("id").primaryKey(),
  sector: text("sector").notNull(),
  date: date("date").notNull(),
  performance: real("performance").notNull(), // Daily performance percentage
  relativeStrength: real("relative_strength"), // Compared to broad market
  atrTrailing: real("atr_trailing"), // Average True Range - volatility
  volume: integer("volume"), // Sector volume
  sentiment: text("sentiment"), // e.g., bullish, bearish, neutral
});

// User watchlists
export const watchlists = pgTable("watchlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const watchlistItems = pgTable("watchlist_items", {
  id: serial("id").primaryKey(),
  watchlistId: integer("watchlist_id").notNull(),
  stockId: integer("stock_id").notNull(),
  notes: text("notes"),
  addedAt: timestamp("added_at").notNull().defaultNow(),
});

// Sector rotation model predictions
export const sectorPredictions = pgTable("sector_predictions", {
  id: serial("id").primaryKey(),
  sector: text("sector").notNull(),
  date: date("date").notNull(),
  predictionFor: date("prediction_for").notNull(), // Date the prediction is for
  score: real("score").notNull(), // Prediction score (0-100)
  confidence: real("confidence"), // Confidence level
  rationale: text("rationale"), // Explanation
});

// Schema definitions for insert operations
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  avatarUrl: true,
});

export const insertStockSchema = createInsertSchema(stocks).pick({
  symbol: true,
  name: true,
  sector: true,
  industry: true,
  description: true,
  marketCap: true,
  peRatio: true,
  dividendYield: true,
  beta: true,
});

export const insertStockPriceSchema = createInsertSchema(stockPrices).pick({
  stockId: true,
  date: true,
  open: true,
  high: true,
  low: true,
  close: true,
  volume: true,
});

export const insertEconomicIndicatorSchema = createInsertSchema(economicIndicators).pick({
  name: true,
  category: true,
  description: true,
  frequencyOfUpdate: true,
  source: true,
});

export const insertEconomicDataSchema = createInsertSchema(economicData).pick({
  indicatorId: true,
  date: true,
  value: true,
  percentChange: true,
  notes: true,
});

export const insertSectorPerformanceSchema = createInsertSchema(sectorPerformance).pick({
  sector: true,
  date: true,
  performance: true,
  relativeStrength: true,
  atrTrailing: true,
  volume: true,
  sentiment: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlists).pick({
  userId: true,
  name: true,
  description: true,
});

export const insertWatchlistItemSchema = createInsertSchema(watchlistItems).pick({
  watchlistId: true,
  stockId: true,
  notes: true,
});

export const insertSectorPredictionSchema = createInsertSchema(sectorPredictions).pick({
  sector: true,
  date: true,
  predictionFor: true,
  score: true,
  confidence: true,
  rationale: true,
});

// Type definitions for TypeScript
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;

export type StockPrice = typeof stockPrices.$inferSelect;
export type InsertStockPrice = z.infer<typeof insertStockPriceSchema>;

export type EconomicIndicator = typeof economicIndicators.$inferSelect;
export type InsertEconomicIndicator = z.infer<typeof insertEconomicIndicatorSchema>;

export type EconomicData = typeof economicData.$inferSelect;
export type InsertEconomicData = z.infer<typeof insertEconomicDataSchema>;

export type SectorPerformance = typeof sectorPerformance.$inferSelect;
export type InsertSectorPerformance = z.infer<typeof insertSectorPerformanceSchema>;

export type Watchlist = typeof watchlists.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;

export type WatchlistItem = typeof watchlistItems.$inferSelect;
export type InsertWatchlistItem = z.infer<typeof insertWatchlistItemSchema>;

export type SectorPrediction = typeof sectorPredictions.$inferSelect;
export type InsertSectorPrediction = z.infer<typeof insertSectorPredictionSchema>;
