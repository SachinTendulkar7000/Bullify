import { useEffect, useRef, useState } from "react";
import { Message, InsertMessage } from "@shared/schema";
import { useAuth } from "./use-auth";

export function useChat(receiverId: number | null) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!user || !receiverId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws?userId=${user.id}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      const message: Message = JSON.parse(event.data);
      setMessages((prev) => [...prev, message]);
    };

    // Load existing messages
    fetch(`/api/messages/${receiverId}`, {
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => setMessages(data))
      .catch(console.error);

    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [user, receiverId]);

  const sendMessage = (content: string) => {
    if (!user || !receiverId || !wsRef.current) return;

    const message: InsertMessage = {
      content,
      senderId: user.id,
      receiverId,
    };

    wsRef.current.send(JSON.stringify(message));
  };

  return { messages, sendMessage };
}
