import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const clients = new Map<number, WebSocket>();

  wss.on("connection", (ws, req) => {
    if (!req.url) return;

    const userId = parseInt(new URLSearchParams(req.url.split("?")[1]).get("userId") || "0");
    if (userId) {
      clients.set(userId, ws);
    }

    ws.on("message", async (data) => {
      try {
        const message = JSON.parse(data.toString());
        const validatedMessage = insertMessageSchema.parse(message);

        const savedMessage = await storage.createMessage(validatedMessage);

        const receiver = clients.get(validatedMessage.receiverId);
        if (receiver?.readyState === WebSocket.OPEN) {
          receiver.send(JSON.stringify(savedMessage));
        }

        ws.send(JSON.stringify(savedMessage));
      } catch (error) {
        console.error("Error handling message:", error);
      }
    });

    ws.on("close", () => {
      clients.delete(userId);
    });
  });

  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const searchQuery = req.query.search?.toString().toLowerCase();
    const users = await storage.getUsers();
    const filteredUsers = users.filter(u => {
      if (u.id === req.user?.id) return false;
      if (!searchQuery) return true;
      return u.username.toLowerCase().includes(searchQuery);
    });
    res.json(filteredUsers);
  });

  app.get("/api/messages/:receiverId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const messages = await storage.getMessages(
      req.user!.id,
      parseInt(req.params.receiverId)
    );
    res.json(messages);
  });

  return httpServer;
}